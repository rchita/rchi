<?php

$dev = 'www.m1150.com';                   //enter your domain name
$spon = 'dtac@gmx.com';                   //enter your email adress

?>