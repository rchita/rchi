<?php
header("Location: ./install/");
?>
