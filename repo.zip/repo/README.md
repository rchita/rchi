# Cydia-Repo-Manager
Cydia Repo Manager - Old Version - Developers only - No support
This is an old version, only for developers, no support !!!!!!!!!

1. Edit the configure.php and enter your details

2. Upload all files and folder to the root of your webspace

2.1. Give all files, folders and subfolders CHMOD 755

3. Run www.your-domain.com/install.php

4. Follow the instructions

5. Is the installation finish you will redirect to the Admin Panel (www.your-domain.com/admin)

6. Set up your Repo:

	- Edit Release (upload your Icons, Create your Repo Release File)
	- save changes !!!

7. Upload your *.deb files

8. Rebuild Packages file ( you'll need to do this after every change on your Repo !!! )

9. Create the depiction file for your uploaded *.deb files

10. PLEASE NOTE, Cydia sometimes need some time to realize changes !!!




Use my forums (damarist.de) for Questions and Remote Installation help or add me on Twitter @damar1st

Thanks for using RepoCMS

