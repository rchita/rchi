 <?php

$subx = "/";

?>